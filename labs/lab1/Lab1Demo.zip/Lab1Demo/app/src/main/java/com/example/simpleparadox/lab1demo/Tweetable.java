package com.example.simpleparadox.lab1demo;

import java.util.Date;

public interface Tweetable {
    public String getMessage();
    public Date getDate();
}
